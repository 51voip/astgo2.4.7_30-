/*! \file
  * \brief 8-bit raw data
  *
  * Source: example.lpc10
  *
  * Copyright (C) 1999-2005, Digium Inc.
  *
  * Distributed under the terms of the GNU General Public License
  *
  */

static unsigned char lpc10_slin_ex[] = {
0x1, 0x8, 0x31, 0x8, 0x31, 0x80, 0x30 };
